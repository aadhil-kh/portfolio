// React profile explorer - JSX on the bundled React runtime.
// Notice there is no `import React` and no script tag: the preview injects an
// import map plus the runtime, and the automatic JSX transform wires the
// `jsx` calls for us. Components below are deliberately small and composable.

import { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';

// ---- Data -------------------------------------------------------------------
// Self-contained demo data; a real app would fetch this from an API.

/** @typedef {{ id: number; name: string; role: string; skills: string[]; bio: string }} Profile */

/** @type {Profile[]} */
const PROFILES = [
  {
    id: 1,
    name: 'Ada Lovelace',
    role: 'Engineer',
    skills: ['algorithms', 'math', 'parsing'],
    bio: 'Writes programs before breakfast and traces them after lunch. Believes a good loop deserves a good comment.',
  },
  {
    id: 2,
    name: 'Grace Hopper',
    role: 'Systems architect',
    skills: ['compilers', 'debugging', 'mentoring'],
    bio: 'Ships compilers and catchphrases in equal measure. Keeps a clock that runs counterclockwise as a reminder.',
  },
  {
    id: 3,
    name: 'Alan Kay',
    role: 'Designer',
    skills: ['interfaces', 'prototyping', 'typography'],
    bio: 'Sketches the future on napkins, then builds just enough of it to argue about. Prefers messages to objects.',
  },
  {
    id: 4,
    name: 'Barbara Liskov',
    role: 'API lead',
    skills: ['abstractions', 'types', 'testing'],
    bio: 'Believes every good interface is a promise. Substitutes carefully and reviews pull requests even more carefully.',
  },
];

// ---- Small components ---------------------------------------------------------

/** Initials avatar: no network, no images - just two letters in a circle. */
function Avatar({ name }) {
  const initials = name
    .split(' ')
    .map((part) => part[0])
    .slice(0, 2)
    .join('');
  return <div className="avatar avatar-fallback" aria-hidden="true">{initials}</div>;
}

/** One profile card. The expand button reveals the bio (aria-expanded). */
function ProfileCard({ profile }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <article className="card">
      <Avatar name={profile.name} />
      <h2 className="name">{profile.name}</h2>
      <p className="role">{profile.role}</p>

      <ul className="skills">
        {profile.skills.map((skill) => (
          <li className="skill" key={skill}>{skill}</li>
        ))}
      </ul>

      {expanded && <p className="details">{profile.bio}</p>}

      <button
        type="button"
        className="toggle"
        aria-expanded={expanded}
        onClick={() => setExpanded((value) => !value)}
      >
        {expanded ? 'Show less' : 'Show more'}
      </button>
    </article>
  );
}

// ---- App -----------------------------------------------------------------------

/** Search + grid. useMemo keeps filtering out of the render path. */
function App() {
  const [query, setQuery] = useState('');

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (q.length === 0) return PROFILES;

    return PROFILES.filter((profile) => {
      const haystack = [profile.name, profile.role, ...profile.skills]
        .join(' ')
        .toLowerCase();
      return haystack.includes(q);
    });
  }, [query]);

  return (
    <div className="app">
      <header className="app-head">
        <h1>Profile explorer</h1>
        <p>Search by name, role, or skill.</p>
      </header>

      <div className="search">
        <span className="glyph" aria-hidden="true">&#9906;</span>
        <input
          type="search"
          placeholder="Search profiles…"
          value={query}
          aria-label="Search profiles"
          onChange={(event) => setQuery(event.target.value)}
        />
      </div>

      {visible.length > 0 ? (
        <div className="grid">
          {visible.map((profile) => (
            <ProfileCard key={profile.id} profile={profile} />
          ))}
        </div>
      ) : (
        <p className="empty">No profiles match “{query.trim()}”.</p>
      )}
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
