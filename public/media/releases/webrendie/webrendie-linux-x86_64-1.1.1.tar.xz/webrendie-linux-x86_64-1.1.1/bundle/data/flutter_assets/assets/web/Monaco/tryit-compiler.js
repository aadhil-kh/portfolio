(function () {
  function normalizeStyleMode(value) {
    value = String(value || "").toLowerCase();
    return value === "scss" || value === "sass" ? value : "css";
  }

  function normalizeScriptMode(value) {
    value = String(value || "").toLowerCase();
    if (value === "ts" || value === "typescript") return "ts";
    if (value === "jsx") return "jsx";
    if (value === "tsx") return "tsx";
    return "js";
  }

  // JSX is plain JavaScript with extra syntax; TSX is type-checked. Keeping them apart is what
  // stops a .jsx author from being told their perfectly good JavaScript has type errors.
  function isTypeScriptMode(mode) {
    return mode === "ts" || mode === "tsx";
  }

  function usesJsx(mode) {
    return mode === "jsx" || mode === "tsx";
  }

  // TypeScript only parses JSX when the file extension says so — a .ts file treats `<div>` as a
  // type assertion and reports a syntax error. The model URI extension therefore selects the
  // parser, so it has to track the mode exactly.
  function scriptExtension(mode) {
    return mode === "tsx" ? ".tsx" : mode === "jsx" ? ".jsx" : mode === "ts" ? ".ts" : ".js";
  }

  function diagnostic(lang, severity, message, line, column) {
    return {
      lang: lang || "js",
      severity: severity || "error",
      message: message || "",
      line: Math.max(1, line || 1),
      column: Math.max(1, column || 1),
    };
  }

  // Dart Sass renders exceptions with terminal escape codes and a multi-line source
  // snippet in Exception#message. For diagnostics we only want the plain first line.
  function stripAnsi(value) {
    return String(value || "").replace(/\x1b\[[0-9;]*m/g, "");
  }

  function sassReady() {
    return !!(window.Sass && typeof window.Sass.compileString === "function");
  }

  // Source spans from Dart Sass are 0-based; the host diagnostic contract is 1-based.
  function spanStart(span) {
    if (!span || !span.start) return { line: 1, column: 1 };
    return {
      line: Math.max(1, (span.start.line || 0) + 1),
      column: Math.max(1, (span.start.column || 0) + 1),
    };
  }

  // Compiles SCSS or indented Sass using the real Dart Sass compiler bundled in
  // sass.bundle.js (window.Sass). Falls back to the raw source if the compiler has
  // not finished loading yet, with an error diagnostic so the user sees it.
  function compileSass(source, mode) {
    if (!sassReady()) {
      return {
        css: String(source || ""),
        diagnostics: [diagnostic("css", "error", "Sass compiler is not ready yet.", 1, 1)],
      };
    }

    var warnings = [];
    var syntax = mode === "sass" ? "indented" : "scss";

    try {
      var result = window.Sass.compileString(String(source || ""), {
        syntax: syntax,
        style: "expanded",
        logger: {
          warn: function (message, options) {
            var pos = spanStart(options && options.span);
            warnings.push(diagnostic(
              "css",
              "warning",
              stripAnsi(message).split("\n")[0].trim(),
              pos.line,
              pos.column
            ));
          },
        },
      });
      return { css: (result && result.css) || "", diagnostics: warnings };
    } catch (error) {
      var pos = spanStart(error && error.span);
      var raw = error && error.message ? String(error.message) : (error ? String(error) : "Sass compilation error.");
      var message = stripAnsi(raw).split("\n")[0].trim() || "Sass compilation error.";
      return { css: "", diagnostics: [diagnostic("css", "error", message, pos.line, pos.column)] };
    }
  }

  function tsSeverity(value) {
    return value === 1 ? "error" : value === 0 ? "warning" : "warning";
  }

  function flattenMessage(message) {
    if (typeof message === "string") return message;
    if (!message) return "";
    if (message.messageText) return flattenMessage(message.messageText);
    return String(message);
  }

  var base64Digits = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

  function decodeVlq(segment) {
    var values = [];
    var value = 0;
    var shift = 0;

    for (var i = 0; i < segment.length; i++) {
      var digit = base64Digits.indexOf(segment[i]);
      if (digit < 0) break;

      var continuation = digit & 32;
      digit &= 31;
      value += digit << shift;

      if (continuation) {
        shift += 5;
        continue;
      }

      var negative = value & 1;
      value >>= 1;
      values.push(negative ? -value : value);
      value = 0;
      shift = 0;
    }

    return values;
  }

  function buildScriptLineMap(mapText) {
    if (!mapText) return [];

    try {
      var map = JSON.parse(mapText);
      var mappingLines = String(map.mappings || "").split(";");
      var entries = [];
      var sourceIndex = 0;
      var sourceLine = 0;
      var sourceColumn = 0;
      var nameIndex = 0;

      for (var generatedLine = 0; generatedLine < mappingLines.length; generatedLine++) {
        var generatedColumn = 0;
        var segments = mappingLines[generatedLine].split(",");

        for (var i = 0; i < segments.length; i++) {
          if (!segments[i]) continue;

          var fields = decodeVlq(segments[i]);
          if (fields.length === 0) continue;

          generatedColumn += fields[0];
          if (fields.length < 4) continue;

          sourceIndex += fields[1];
          sourceLine += fields[2];
          sourceColumn += fields[3];
          if (fields.length >= 5) nameIndex += fields[4];

          entries.push({
            generatedLine: generatedLine + 1,
            generatedColumn: generatedColumn + 1,
            sourceLine: sourceLine + 1,
            sourceColumn: sourceColumn + 1,
          });
        }
      }

      return entries;
    } catch (error) {
      return [];
    }
  }

  function stripSourceMappingUrl(js) {
    return String(js || "").replace(/\r?\n?\/\/# sourceMappingURL=.*(?:\r?\n)?\s*$/, "");
  }

  function liveScriptModelFor(source, mode) {
    var editor = window.editors && window.editors.js;
    var model = editor && typeof editor.getModel === "function" ? editor.getModel() : null;
    var expectedLanguage = isTypeScriptMode(mode) ? "typescript" : "javascript";
    if (!model || typeof model.getLanguageId !== "function" || model.getLanguageId() !== expectedLanguage) {
      return null;
    }

    // In a JSX mode the live model must also carry a .jsx/.tsx URI or TypeScript will not parse
    // its JSX at all. setLanguageModes recreates the model on a mode switch; if we somehow run
    // before that lands, fall back to a scratch model rather than compile against a stale URI.
    if (usesJsx(mode)) {
      var uri = model.uri && typeof model.uri.toString === "function" ? model.uri.toString() : "";
      if (!new RegExp("\\" + scriptExtension(mode) + "$", "i").test(uri)) return null;
    }

    return typeof model.getValue === "function" && model.getValue() === source ? model : null;
  }

  function pushTypeScriptDiagnostic(output, seen, model, item) {
    var pos = model.getPositionAt(item.start || 0);
    var message = flattenMessage(item.messageText);
    var key = pos.lineNumber + ":" + pos.column + ":" + message;
    if (seen[key]) return;

    seen[key] = true;
    output.push(diagnostic("js", tsSeverity(item.category), message, pos.lineNumber, pos.column));
  }

  async function compileScript(source, mode) {
    source = source == null ? "" : String(source);
    mode = normalizeScriptMode(mode);

    if (!window.monaco) {
      return {
        js: source,
        diagnostics: [diagnostic("js", "error", "TypeScript compiler is not ready.", 1, 1)],
        scriptLineMap: [],
      };
    }

    // Prefer the live JS/TS editor model. A second temporary script with the same snippet shares
    // TypeScript's global scope and produces false "Cannot redeclare block-scoped variable" markers.
    var model = liveScriptModelFor(source, mode);
    var ownsModel = !model;
    if (ownsModel) {
      model = monaco.editor.createModel(
        source,
        isTypeScriptMode(mode) ? "typescript" : "javascript",
        monaco.Uri.parse(
          "inmemory://tryit/snapshot-" + Date.now() + "-" + Math.random().toString(36).slice(2) + scriptExtension(mode)
        )
      );
    }

    try {
      var uri = model.uri.toString();
      // JSX (untyped) is served by the JavaScript language service, TS/TSX by the TypeScript one.
      // Asking the wrong service for a model it does not own yields an empty emit.
      var getWorker = isTypeScriptMode(mode)
        ? await monaco.languages.typescript.getTypeScriptWorker()
        : await monaco.languages.typescript.getJavaScriptWorker();
      var worker = await getWorker(model.uri);
      var diagnostics = [];
      var seenDiagnostics = Object.create(null);

      var allDiagnostics = []
        .concat(await worker.getSyntacticDiagnostics(uri))
        .concat(await worker.getSemanticDiagnostics(uri));

      allDiagnostics.forEach(function (d) {
        pushTypeScriptDiagnostic(diagnostics, seenDiagnostics, model, d);
      });

      var emit = await worker.getEmitOutput(uri);
      if (emit.diagnostics) {
        emit.diagnostics.forEach(function (d) {
          pushTypeScriptDiagnostic(diagnostics, seenDiagnostics, model, d);
        });
      }

      var output = (emit.outputFiles || []).find(function (file) { return /\.js($|\?)/i.test(file.name || ""); });
      var sourceMap = (emit.outputFiles || []).find(function (file) { return /\.js\.map($|\?)/i.test(file.name || ""); });
      return {
        js: output ? stripSourceMappingUrl(output.text) : source,
        diagnostics: diagnostics,
        scriptLineMap: buildScriptLineMap(sourceMap && sourceMap.text),
      };
    } finally {
      if (ownsModel) {
        model.dispose();
      }
    }
  }

  async function compileProject(input) {
    input = input || {};
    var styleMode = normalizeStyleMode(input.styleMode);
    var scriptMode = normalizeScriptMode(input.scriptMode);
    var styleResult = styleMode === "css"
      ? { css: input.css || "", diagnostics: [] }
      : compileSass(input.css || "", styleMode);
    var scriptResult = scriptMode === "js"
      ? { js: input.js || "", diagnostics: [], scriptLineMap: [] }
      : await compileScript(input.js || "", scriptMode);
    var diagnostics = []
      .concat(styleResult.diagnostics || [])
      .concat(scriptResult.diagnostics || []);

    return {
      ok: diagnostics.every(function (item) { return item.severity !== "error"; }),
      html: input.html || "",
      css: styleResult.css || "",
      js: scriptResult.js || "",
      styleMode: styleMode,
      scriptMode: scriptMode,
      diagnostics: diagnostics,
      scriptLineMap: scriptResult.scriptLineMap || [],
    };
  }

  window.TryitCompiler = {
    compileProject: compileProject,
  };
})();
