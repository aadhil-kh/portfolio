// Interactive pricing selector.
// Two jobs: (1) swap every plan's price when the billing cycle changes, and
// (2) track which plan is selected, keeping the DOM's aria-pressed state and
// the status line in sync. No frameworks, no state library - just a couple of
// small helper functions.

/** @type {'monthly' | 'annual'} */
let cycle = 'monthly';

const plans = document.querySelectorAll('#plans .plan');
const cycleButtons = document.querySelectorAll('.cycle-btn');
const status = document.querySelector('#status');

// Human label for a cycle value, used in the status sentence.
function cycleLabel(value) {
  return value === 'annual' ? 'annually' : 'monthly';
}

// Update every plan card's price + billing note for the active cycle.
// Prices come from each card's data-monthly / data-annual attributes.
function renderPrices() {
  plans.forEach((plan) => {
    const amount = plan.querySelector('.amount');
    const period = plan.querySelector('.period');
    const note = plan.querySelector('.plan-note');

    const value = cycle === 'annual'
      ? plan.dataset.annual
      : plan.dataset.monthly;

    amount.textContent = `$${value}`;
    period.textContent = '/month';
    note.textContent = cycle === 'annual'
      ? 'Billed annually'
      : 'Billed monthly';
  });
}

// Rebuild the status line from the current selection. Called after every
// interaction so the live region always matches what sighted users see.
function renderStatus() {
  const selected = document.querySelector('#plans .plan[aria-pressed="true"]');
  if (!selected) return;

  const name = selected.querySelector('.plan-name').textContent;
  const price = selected.querySelector('.amount').textContent;
  status.textContent =
    `${name} selected at ${price}/month, billed ${cycleLabel(cycle)}.`;
}

// Billing cycle buttons: toggle the group's active state and refresh prices.
cycleButtons.forEach((button) => {
  button.addEventListener('click', () => {
    cycle = button.dataset.cycle;

    cycleButtons.forEach((other) => {
      const active = other === button;
      other.classList.toggle('is-active', active);
      other.setAttribute('aria-pressed', String(active));
    });

    renderPrices();
    renderStatus();
  });
});

// Plan cards: single-select. Clicking a card selects it; clicking the selected
// card keeps it selected (a pricing page always has exactly one active plan).
plans.forEach((plan) => {
  plan.addEventListener('click', () => {
    plans.forEach((other) => {
      other.setAttribute('aria-pressed', String(other === plan));
    });
    renderStatus();
  });
});

// First paint.
renderPrices();
renderStatus();
