function __tryitInstallCompat(react, reactDom, reactDomClient, jsxRuntime) {
  if (!react) return;

  // React's entries are CommonJS, so the namespace carries the real API on `default`; Preact's
  // are true ESM and carry it directly. Merging covers both without branching on the runtime.
  //
  // The `missing` check is what keeps window.React identical to the object an `import React from
  // "react"` gets: for a CJS package the namespace is just module.exports plus a `default` alias,
  // so returning that default preserves identity instead of handing out a copy. Packages that do
  // have namespace-only exports (preact/compat) still get the merged object.
  function flatten(ns) {
    if (!ns) return {};
    var d = ns.default;
    if (!d || (typeof d !== 'object' && typeof d !== 'function')) return ns;
    var missing = false;
    for (var a in ns) { if (a !== 'default' && !(a in d)) { missing = true; break; } }
    if (!missing) return d;
    var out = {};
    for (var b in ns) out[b] = ns[b];
    for (var c in d) out[c] = d[c];
    return out;
  }

  var React = flatten(react);
  var ReactDOMClient = flatten(reactDomClient);
  var ReactDOM = flatten(reactDom);
  for (var key in ReactDOMClient) ReactDOM[key] = ReactDOMClient[key];

  var warned = {};
  function notice(name, text) {
    if (warned[name]) return;
    warned[name] = true;
    if (window.console && console.warn) console.warn(text);
  }

  // One root per container, exactly like the legacy renderer's internal bookkeeping: calling
  // render() twice on the same node must update in place, not mount a second tree.
  var roots = typeof WeakMap === 'function' ? new WeakMap() : null;
  function rootFor(container, hydrate, element) {
    var existing = roots && roots.get(container);
    if (existing) return existing;
    var root = hydrate
      ? ReactDOMClient.hydrateRoot(container, element)
      : ReactDOMClient.createRoot(container);
    if (roots) roots.set(container, root);
    return root;
  }

  // Legacy render was synchronous: the line after it could read container.textContent, and plenty
  // of old snippets do. createRoot().render() is not, so flush it — that restores the one
  // behaviour most likely to be depended on, and lets the callback run at the right moment.
  function commit(root, element) {
    if (typeof ReactDOM.flushSync === 'function') {
      try {
        ReactDOM.flushSync(function () { root.render(element); });
        return true;
      } catch (error) {
        // flushSync refuses to nest inside an ongoing render; fall through to the async path.
      }
    }
    root.render(element);
    return false;
  }

  if (ReactDOMClient.createRoot && !ReactDOM.render) {
    ReactDOM.render = function (element, container, callback) {
      notice('render',
        'ReactDOM.render was removed in React 19. This editor is running it through ' +
        'createRoot() and flushing synchronously, so older code keeps working. It returns null ' +
        'rather than a component instance; use a ref if you need the DOM node. New code should ' +
        'use ReactDOM.createRoot(container).render(element).');
      var root = rootFor(container, false, element);
      var flushed = commit(root, element);
      if (typeof callback === 'function') {
        if (flushed) callback(); else setTimeout(callback, 0);
      }
      return null;
    };

    ReactDOM.hydrate = function (element, container, callback) {
      notice('hydrate',
        'ReactDOM.hydrate was removed in React 19. This editor is running it through ' +
        'hydrateRoot(). New code should use ReactDOM.hydrateRoot(container, element).');
      rootFor(container, true, element);
      if (typeof callback === 'function') setTimeout(callback, 0);
      return null;
    };

    ReactDOM.unmountComponentAtNode = function (container) {
      notice('unmountComponentAtNode',
        'ReactDOM.unmountComponentAtNode was removed in React 19. This editor is running it ' +
        'through root.unmount(). New code should keep the root returned by createRoot() and ' +
        'call unmount() on it.');
      var root = roots && roots.get(container);
      if (!root) return false;
      root.unmount();
      roots['delete'](container);
      return true;
    };
  }

  if (!ReactDOM.findDOMNode) {
    ReactDOM.findDOMNode = function (value) {
      notice('findDOMNode',
        'ReactDOM.findDOMNode was removed in React 19 and cannot be emulated: it needed ' +
        'renderer internals that no longer exist. It returns a DOM node unchanged and null for ' +
        'anything else here. Use a ref instead.');
      return value && value.nodeType === 1 ? value : null;
    };
  }

  window.React = window.React || React;
  window.ReactDOM = window.ReactDOM || ReactDOM;
  window.ReactDOMClient = window.ReactDOMClient || ReactDOMClient;

  // CommonJS never existed in a browser, but snippets copied out of Node or webpack projects
  // open with require(). Only the four specifiers we actually bundle resolve; anything else gets
  // a message that names the way out instead of "require is not defined".
  if (typeof window.require === 'undefined') {
    var modules = {
      'react': React,
      'react-dom': ReactDOM,
      'react-dom/client': ReactDOMClient,
      'react/jsx-runtime': flatten(jsxRuntime),
      'react/jsx-dev-runtime': flatten(jsxRuntime)
    };
    window.require = function (id) {
      if (Object.prototype.hasOwnProperty.call(modules, id)) return modules[id];
      throw new Error(
        'require("' + id + '") is not available in the preview. Only react, react-dom, ' +
        'react-dom/client and react/jsx-runtime are bundled; load anything else with a ' +
        '<script> tag or an import from a CDN.');
    };
  }
}
