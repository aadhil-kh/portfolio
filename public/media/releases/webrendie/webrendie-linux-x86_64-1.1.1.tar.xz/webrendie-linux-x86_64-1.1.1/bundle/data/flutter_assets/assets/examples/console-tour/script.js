// Console tour.
// Each demo prints one flavor of the captured console. Everything here is
// standard console API - the app intercepts the calls and renders them with
// structure preserved. Run a demo, then filter, expand, and click source chips
// in the console pane.

const statusLine = document.querySelector('#status');
const demoButtons = document.querySelectorAll('.demo');

const demos = {
  levels: showLevels,
  styled: showStyledText,
  tables: showTables,
  trees: showTrees,
  groups: showGroups,
  timers: showTimers,
  assertions: showAssertions,
  uncaught: showUncaught,
};

demoButtons.forEach((button) => {
  button.addEventListener('click', () => {
    demos[button.dataset.demo]();
    statusLine.textContent = `Ran “${button.querySelector('.demo-title').textContent}” - see the console pane.`;
  });
});

// Levels - each one keeps its own color, filter bucket, and count badge.
function showLevels() {
  console.log('log - the everyday workhorse');
  console.info('info - something worth knowing, not alarming');
  console.warn('warn - recoverable, but look soon');
  console.error('error - something failed');
  console.debug('debug - hidden until you switch the filter to it');
  console.trace('trace - a warn-level entry carrying a stack');
}

// Styled text - each %c consumes the next argument as the CSS for the text
// that follows; an empty style resets. The console renders color, font-weight,
// font-style, and text-decoration.
function showStyledText() {
  console.log(
    '%cplain %cbold %citalic %cunderlined %cstruck %creset',
    '',
    'font-weight:bold',
    'font-style:italic',
    'text-decoration:underline',
    'text-decoration:line-through',
    ''
  );
  console.log('%cFAIL%c 3 checks failed (color and weight carry the signal)', 'color:#cf222e;font-weight:bold', '');
}

// Tables - arrays of objects render as a grid; the optional second argument
// picks and orders columns.
function showTables() {
  const planets = [
    { name: 'Mercury', moons: 0, gravity: 3.7 },
    { name: 'Venus', moons: 0, gravity: 8.9 },
    { name: 'Earth', moons: 1, gravity: 9.8 },
    { name: 'Mars', moons: 2, gravity: 3.7 },
  ];
  console.table(planets);
  console.table(planets, ['name', 'moons']);
}

// Object trees - objects and arrays become lazy, expandable trees. Circular
// references are detected and rendered as [Circular]; errors keep their stack.
function showTrees() {
  const mission = {
    name: 'Apollo 11',
    crew: { commander: 'Armstrong', pilot: 'Collins', lemPilot: 'Aldrin' },
    dates: { launch: '1969-07-16', landing: '1969-07-20' },
  };
  console.log('Objects render as expandable trees - click the arrows:', mission);
  console.log('Arrays too, mixed types and all:', ['heat shield', 'parachutes', 3, true]);

  const a = { name: 'a' };
  const b = { partner: a };
  a.partner = b;
  console.log('Circular references render as [Circular], not a crash:', a);

  console.error(new Error('engines at 60%'));
}

// Groups - entries nest under a header; groupCollapsed starts folded.
function showGroups() {
  console.group('Launch sequence');
  console.log('Ignition sequence start');
  console.groupCollapsed('Pre-flight checks');
  console.log('Guidance: internal');
  console.log('Propellant level: 100%');
  console.groupEnd();
  console.log('All engines running');
  console.groupEnd();
}

// Timers & counters - time/timeLog/timeEnd report elapsed milliseconds;
// count tallies every hit for a label, and countReset starts it over.
async function showTimers() {
  console.count('tour');
  console.count('tour');
  console.countReset('tour');
  console.count('tour'); // back to 1 after the reset

  console.time('coast');
  await wait(300);
  console.timeLog('coast', 'halfway there');
  await wait(150);
  console.timeEnd('coast');
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Assertions - silent when the expression is truthy, an error entry when not.
function showAssertions() {
  console.assert(1 + 1 === 2, 'math still works (this is never printed)');
  console.assert(document.getElementById('does-not-exist'), 'the element was missing - so this prints');
}

// Uncaught - errors nobody catches still land in the console, with a source
// chip (js:line:col) that reveals the exact line in the editor when clicked.
function showUncaught() {
  setTimeout(() => {
    throw new Error('nobody caught me - click my source chip');
  }, 0);
}

// A greeting so the console is never empty on first open.
console.log('%cConsole tour ready%c - click a demo above.', 'font-weight:bold', '');
