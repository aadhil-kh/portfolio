// Typed task board - TypeScript.
// The point of this example: model the domain with types first (Task, Filter,
// TaskStatus), then let the compiler check every place that touches them.
// Rendering is plain DOM - no framework needed at this size.

/** A task's lifecycle state. */
type TaskStatus = 'open' | 'done';

/** One item on the board. */
interface Task {
  readonly id: number;
  text: string;
  status: TaskStatus;
  createdAt: Date;
}

/** Which tasks the list shows. */
type Filter = 'all' | 'open' | 'done';

// ---- State -----------------------------------------------------------------

let nextId: number = 1;
let tasks: Task[] = [
  { id: nextId++, text: 'Sketch the board layout', status: 'done', createdAt: new Date() },
  { id: nextId++, text: 'Write the SCSS card mixin', status: 'done', createdAt: new Date() },
  { id: nextId++, text: 'Type the task model', status: 'open', createdAt: new Date() },
];
let filter: Filter = 'all';

// ---- Element handles (all non-null: they exist in the HTML tab) ------------

const form = document.querySelector<HTMLFormElement>('#add-form')!;
const input = document.querySelector<HTMLInputElement>('#task-input')!;
const list = document.querySelector<HTMLUListElement>('#task-list')!;
const summary = document.querySelector<HTMLElement>('#summary')!;

// Narrow a radio group's checked value to Filter - anything else is a bug we
// want to hear about, so assert rather than silently default.
function currentFilter(): Filter {
  const checked = document.querySelector<HTMLInputElement>('input[name="filter"]:checked');
  const value = (checked?.value ?? 'all') as Filter;
  return value;
}

// ---- Queries ----------------------------------------------------------------

/** Tasks visible under the active filter. */
function visibleTasks(): Task[] {
  return tasks.filter((task) =>
    filter === 'all' ? true : task.status === filter
  );
}

/** Counts for the summary line. */
function counts(): { open: number; done: number } {
  return {
    open: tasks.filter((t) => t.status === 'open').length,
    done: tasks.filter((t) => t.status === 'done').length,
  };
}

// ---- Actions ----------------------------------------------------------------

function addTask(text: string): void {
  tasks.push({ id: nextId++, text, status: 'open', createdAt: new Date() });
}

function toggleTask(id: number): void {
  const task = tasks.find((t) => t.id === id);
  if (task) {
    task.status = task.status === 'done' ? 'open' : 'done';
  }
}

function removeTask(id: number): void {
  tasks = tasks.filter((t) => t.id !== id);
}

// ---- Rendering --------------------------------------------------------------

// Rebuild the whole list on each change. At board scale this is cheaper and
// far simpler than incremental DOM patching.
function render(): void {
  list.innerHTML = '';

  for (const task of visibleTasks()) {
    const item = document.createElement('li');
    item.className = 'task' + (task.status === 'done' ? ' is-done' : '');

    const dot = document.createElement('span');
    dot.className = 'dot';
    dot.setAttribute('aria-hidden', 'true');

    const text = document.createElement('span');
    text.className = 'text';
    text.textContent = task.text;

    const toggle = document.createElement('button');
    toggle.type = 'button';
    toggle.textContent = task.status === 'done' ? 'Reopen' : 'Done';
    toggle.setAttribute('aria-label', `Mark "${task.text}" as ${task.status === 'done' ? 'open' : 'done'}`);
    toggle.addEventListener('click', () => {
      toggleTask(task.id);
      render();
    });

    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'remove';
    remove.textContent = 'Remove';
    remove.setAttribute('aria-label', `Remove "${task.text}"`);
    remove.addEventListener('click', () => {
      removeTask(task.id);
      render();
    });

    item.append(dot, text, toggle, remove);
    list.append(item);
  }

  const { open, done } = counts();
  summary.textContent =
    `${tasks.length} task${tasks.length === 1 ? '' : 's'} - ${open} open, ${done} done`;
}

// ---- Wiring -----------------------------------------------------------------

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const text = input.value.trim();
  if (text.length === 0) return;
  addTask(text);
  input.value = '';
  render();
});

for (const radio of document.querySelectorAll<HTMLInputElement>('input[name="filter"]')) {
  radio.addEventListener('change', () => {
    filter = currentFilter();
    render();
  });
}

// First paint.
render();
