(function () {
  // Seed config. Mutated in place by setOptions() when the host pushes the user's saved
  // Prettier preferences (Settings → Formatting), so format actions pick them up live.
  const prettierOptions = {
    printWidth: 100,
    tabWidth: 2,
    useTabs: false,
    semi: true,
    singleQuote: false,
    trailingComma: "es5",
    bracketSpacing: true,
    endOfLine: "lf",
  };

  // Only these keys are accepted from the host, so an unexpected payload can never inject a
  // Prettier option the UI doesn't expose (e.g. parser/plugins, which are set per-format).
  const ALLOWED_OPTIONS = [
    "printWidth",
    "tabWidth",
    "useTabs",
    "semi",
    "singleQuote",
    "trailingComma",
    "bracketSpacing",
    "endOfLine",
  ];

  function setOptions(options) {
    if (!options) {
      return;
    }

    const parsed = typeof options === "string" ? JSON.parse(options) : options;
    for (const key of ALLOWED_OPTIONS) {
      if (parsed[key] !== undefined) {
        prettierOptions[key] = parsed[key];
      }
    }
  }

  const languageToParser = {
    html: "html",
    css: "css",
    scss: "scss",
    javascript: "babel",
    typescript: "typescript",
  };

  let formattersRegistered = false;

  // Prettier's ~1.8 MB of browser bundles are loaded lazily on the first format, not at startup.
  const PRETTIER_SOURCES = [
    "../Prettier/standalone.js",
    "../Prettier/plugins/babel.js",
    "../Prettier/plugins/estree.js",
    "../Prettier/plugins/typescript.js",
    "../Prettier/plugins/html.js",
    "../Prettier/plugins/postcss.js",
  ];

  let prettierLoadPromise = null;

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = src;
      s.async = false; // preserve insertion order (standalone before its plugins)
      s.onload = resolve;
      s.onerror = () => reject(new Error("Failed to load Prettier asset: " + src));
      document.head.appendChild(s);
    });
  }

  // Loads Prettier on demand. Its UMD bundles only assign window.prettier / window.prettierPlugins
  // when no AMD `define` is present — but Monaco's loader defines one — so we hide `define` while
  // they execute, otherwise they register as anonymous AMD modules and the globals never appear.
  function ensurePrettier() {
    if (window.prettier && window.prettierPlugins) return Promise.resolve();
    if (prettierLoadPromise) return prettierLoadPromise;

    const savedDefine = window.define;
    window.define = undefined;

    prettierLoadPromise = Promise.all(PRETTIER_SOURCES.map(loadScript)).then(
      () => { window.define = savedDefine; },
      (err) => { window.define = savedDefine; prettierLoadPromise = null; throw err; }
    );

    return prettierLoadPromise;
  }

  function getParser(languageId) {
    return languageToParser[languageId] || "";
  }

  function getPrettier() {
    if (!window.prettier || !window.prettierPlugins) {
      throw new Error("Prettier browser assets are not loaded.");
    }

    return window.prettier;
  }

  async function formatString(source, languageId) {
    const parser = getParser(languageId);

    if (!parser) {
      throw new Error("No Prettier parser configured for language: " + languageId);
    }

    await ensurePrettier();

    return await getPrettier().format(source || "", {
      ...prettierOptions,
      parser,
      plugins: window.prettierPlugins,
    });
  }

  async function formatEditor(editor) {
    const model = editor && editor.getModel();
    if (!model) {
      return "";
    }

    const formatted = await formatString(model.getValue(), model.getLanguageId());

    editor.pushUndoStop();
    editor.executeEdits("prettier-format", [
      {
        range: model.getFullModelRange(),
        text: formatted,
        forceMoveMarkers: true,
      },
    ]);
    editor.pushUndoStop();

    return formatted;
  }

  // Turns off Monaco's own built-in formatting for a language service, leaving only formatting
  // capabilities off while keeping diagnostics/completion/hovers/etc. untouched. Without this the
  // built-in HTML/CSS/TS formatters register (lazily, so they win the conflict) and Monaco's
  // "Format Document" runs them instead of Prettier.
  function disableBuiltInFormatting(defaults) {
    if (!defaults || typeof defaults.setModeConfiguration !== "function") {
      return;
    }

    const current = defaults.modeConfiguration || {};
    defaults.setModeConfiguration(
      Object.assign({}, current, {
        documentFormattingEdits: false,
        documentRangeFormattingEdits: false,
        onTypeFormattingEdits: false,
      })
    );
  }

  function disableBuiltInFormatters(monaco) {
    const langs = monaco.languages || {};

    if (langs.typescript) {
      disableBuiltInFormatting(langs.typescript.typescriptDefaults);
      disableBuiltInFormatting(langs.typescript.javascriptDefaults);
    }
    if (langs.css) {
      disableBuiltInFormatting(langs.css.cssDefaults);
      disableBuiltInFormatting(langs.css.scssDefaults);
      disableBuiltInFormatting(langs.css.lessDefaults);
    }
    if (langs.html) {
      disableBuiltInFormatting(langs.html.htmlDefaults);
    }
  }

  function registerPrettierFormatters(monaco) {
    if (formattersRegistered) {
      return;
    }

    // Make Prettier the only document formatter so "Format Document" (context menu / Shift+Alt+F)
    // uses it rather than Monaco's built-in formatters.
    disableBuiltInFormatters(monaco);

    const languages = ["html", "css", "scss", "javascript", "typescript"];

    for (const language of languages) {
      monaco.languages.registerDocumentFormattingEditProvider(language, {
        async provideDocumentFormattingEdits(model) {
          const formatted = await formatString(model.getValue(), model.getLanguageId());

          return [
            {
              range: model.getFullModelRange(),
              text: formatted,
            },
          ];
        },
      });
    }

    formattersRegistered = true;
  }

  window.MonacoPrettierFormatter = {
    formatString,
    formatEditor,
    registerPrettierFormatters,
    setOptions,
  };
})();
