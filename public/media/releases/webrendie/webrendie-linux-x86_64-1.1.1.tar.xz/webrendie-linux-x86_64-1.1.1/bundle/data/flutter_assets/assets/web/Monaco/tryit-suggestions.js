(function () {
    var catalog = { assets: [], mockApi: [] };
    var registered = false;

    function setSuggestionCatalog(next) {
        next = next || {};
        catalog = {
            assets: Array.isArray(next.assets) ? next.assets.filter(hasPath) : [],
            mockApi: Array.isArray(next.mockApi) ? next.mockApi.filter(hasPath) : []
        };
    }

    function hasPath(item) {
        return item && typeof item.path === 'string' && item.path.length > 0;
    }

    function register(monaco) {
        if (registered || !monaco || !monaco.languages) { return; }
        registered = true;

        var triggers = ['"', "'", '`', '/', '_', '.', '(', ','];

        monaco.languages.registerCompletionItemProvider('html', {
            triggerCharacters: triggers,
            provideCompletionItems: function (model, position) {
                return provideHtmlCompletions(monaco, model, position);
            }
        });

        ['css', 'scss', 'less'].forEach(function (language) {
            monaco.languages.registerCompletionItemProvider(language, {
                triggerCharacters: triggers,
                provideCompletionItems: function (model, position) {
                    return provideCssCompletions(monaco, model, position);
                }
            });
        });

        ['javascript', 'typescript'].forEach(function (language) {
            monaco.languages.registerCompletionItemProvider(language, {
                triggerCharacters: triggers,
                provideCompletionItems: function (model, position) {
                    return provideJsCompletions(monaco, model, position);
                }
            });
        });
    }

    function provideHtmlCompletions(monaco, model, position) {
        var attrContext = getHtmlAttributeContext(monaco, model, position);
        var cssContext = getCssUrlContext(monaco, model, position);

        if (cssContext && ((attrContext && attrContext.attr === 'style') || isInsideHtmlElement(model, position, 'style'))) {
            return assetResult(monaco, cssContext, cssAssetFilter(cssContext));
        }

        if (isInsideHtmlElement(model, position, 'script')) {
            var scriptContext = getJsStringContext(monaco, model, position);
            if (scriptContext) {
                return jsResult(monaco, scriptContext);
            }
        }

        if (!attrContext || shouldSkipPrefix(attrContext.prefix)) {
            return emptyResult();
        }

        if (attrContext.attr === 'srcset') {
            attrContext = adjustSrcsetContext(monaco, attrContext);
        }

        var includeApi = shouldIncludeApiForHtml(attrContext);
        var assetFilter = htmlAssetFilter(attrContext);
        if (assetFilter === false && !includeApi) {
            return emptyResult();
        }

        var suggestions = [];
        if (assetFilter !== false) {
            addAssetSuggestions(monaco, suggestions, attrContext, assetFilter, 1);
        }
        if (includeApi) {
            addApiSuggestions(monaco, suggestions, attrContext, 0);
        }

        return { suggestions: suggestions };
    }

    function provideCssCompletions(monaco, model, position) {
        var context = getCssUrlContext(monaco, model, position);
        if (!context || shouldSkipPrefix(context.prefix)) {
            return emptyResult();
        }

        return assetResult(monaco, context, cssAssetFilter(context));
    }

    function provideJsCompletions(monaco, model, position) {
        var context = getJsStringContext(monaco, model, position);
        if (!context || shouldSkipPrefix(context.prefix)) {
            return emptyResult();
        }

        return jsResult(monaco, context);
    }

    function jsResult(monaco, context) {
        var suggestions = [];
        if (context.intent === 'script') {
            addAssetSuggestions(monaco, suggestions, context, kindFilter(['script']), 0);
        } else if (context.intent === 'request') {
            addApiSuggestions(monaco, suggestions, context, 0);
            addAssetSuggestions(monaco, suggestions, context, null, 1);
        } else if (context.intent === 'api') {
            addApiSuggestions(monaco, suggestions, context, 0);
        } else {
            addAssetSuggestions(monaco, suggestions, context, null, 0);
            if (context.prefix.indexOf('/api') === 0) {
                addApiSuggestions(monaco, suggestions, context, 0);
            }
        }
        return { suggestions: suggestions };
    }

    function assetResult(monaco, context, filter) {
        var suggestions = [];
        addAssetSuggestions(monaco, suggestions, context, filter, 0);
        return { suggestions: suggestions };
    }

    function emptyResult() {
        return { suggestions: [] };
    }

    function addAssetSuggestions(monaco, suggestions, context, filter, group) {
        var kinds = monaco.languages.CompletionItemKind;
        catalog.assets.forEach(function (asset, index) {
            if (filter && !filter(asset)) { return; }
            var insertText = pathForContext(asset.path, context);
            suggestions.push({
                label: asset.label || asset.path,
                kind: assetKind(monaco, asset.kind),
                detail: asset.detail || asset.contentType || 'Project asset',
                documentation: assetDocumentation(asset),
                insertText: insertText,
                filterText: assetFilterText(asset.path),
                sortText: sortText(group, index),
                range: context.range
            });
        });
    }

    function addApiSuggestions(monaco, suggestions, context, group) {
        catalog.mockApi.forEach(function (route, index) {
            var insertText = route.insertText || route.path;
            suggestions.push({
                label: route.label || route.path,
                kind: apiKind(monaco, route.kind),
                detail: route.detail || 'Mock API route',
                documentation: routeDocumentation(route),
                insertText: insertText,
                insertTextRules: route.isSnippet
                    ? monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet
                    : undefined,
                filterText: apiFilterText(route),
                sortText: sortText(group, index),
                range: context.range
            });
        });
    }

    function assetKind(monaco, kind) {
        var itemKind = monaco.languages.CompletionItemKind;
        switch (kind) {
            case 'script': return itemKind.Module;
            case 'style': return itemKind.Color;
            case 'font': return itemKind.Text;
            case 'image':
            case 'media':
            case 'data':
            case 'document':
            case 'page':
            default: return itemKind.File;
        }
    }

    function apiKind(monaco, kind) {
        var itemKind = monaco.languages.CompletionItemKind;
        return kind === 'mock-utility' ? itemKind.Function : itemKind.Reference;
    }

    function assetDocumentation(asset) {
        var absolute = asset.path.charAt(0) === '/' ? asset.path : '/' + asset.path;
        return (asset.scope || 'Project') + ' asset available as `' + asset.path + '` or `' + absolute + '`.';
    }

    function routeDocumentation(route) {
        var scope = route.scope ? route.scope + ' ' : '';
        return scope + 'mock API route served by the offline preview host.';
    }

    function sortText(group, index) {
        return String(group || 0) + '-' + String(index).padStart(5, '0');
    }

    function pathForContext(path, context) {
        var prefix = context.prefix || '';
        if (path.charAt(0) === '/') { return path; }
        if (prefix.indexOf('./') === 0) { return './' + path; }
        if (prefix.charAt(0) === '/') { return '/' + path; }
        return path;
    }

    function assetFilterText(path) {
        return path + ' /' + path + ' ./' + path;
    }

    function apiFilterText(route) {
        var path = route.path || route.label || '';
        return path + ' ' + path.replace(/^\//, '');
    }

    function shouldSkipPrefix(prefix) {
        prefix = String(prefix || '').toLowerCase();
        return prefix.indexOf('http:') === 0 ||
            prefix.indexOf('https:') === 0 ||
            prefix.indexOf('data:') === 0 ||
            prefix.indexOf('blob:') === 0 ||
            prefix.indexOf('mailto:') === 0 ||
            prefix.indexOf('tel:') === 0 ||
            prefix.indexOf('#') === 0 ||
            prefix.indexOf('../') === 0;
    }

    function htmlAssetFilter(context) {
        var tag = context.tag;
        var attr = context.attr;
        var before = (context.before || '').toLowerCase();

        if (attr === 'action' || attr === 'formaction') { return false; }
        if (tag === 'img' && attr === 'srcset') { return kindFilter(['image']); }
        if (tag === 'video' && attr === 'poster') { return kindFilter(['image']); }
        if (tag === 'img' && attr === 'src') { return kindFilter(['image']); }
        if (tag === 'input' && attr === 'src' && /\btype\s*=\s*["']?image\b/i.test(before)) { return kindFilter(['image']); }
        if (tag === 'script' && attr === 'src') { return kindFilter(['script']); }
        if (tag === 'source' && (attr === 'src' || attr === 'srcset')) { return kindFilter(['image', 'media']); }
        if ((tag === 'video' || tag === 'audio') && attr === 'src') { return kindFilter(['media']); }
        if (tag === 'track' && attr === 'src') { return kindFilter(['data', 'document']); }
        if (tag === 'link' && attr === 'href') {
            if (/\brel\s*=\s*["'][^"']*stylesheet/i.test(before)) { return kindFilter(['style']); }
            if (/\brel\s*=\s*["'][^"']*(?:icon|apple-touch-icon)/i.test(before)) { return kindFilter(['image']); }
            if (/\brel\s*=\s*["'][^"']*preload/i.test(before)) { return preloadAssetFilter(before); }
            return false;
        }
        if (tag === 'iframe' && attr === 'src') { return kindFilter(['page']); }
        if ((tag === 'a' || tag === 'area') && attr === 'href') { return null; }
        if (tag === 'object' && attr === 'data') { return null; }
        if (tag === 'embed' && attr === 'src') { return null; }
        return false;
    }

    function preloadAssetFilter(before) {
        var asMatch = before.match(/\bas\s*=\s*["']?([A-Za-z0-9_-]+)/i);
        var as = asMatch ? asMatch[1].toLowerCase() : '';
        switch (as) {
            case 'script': return kindFilter(['script']);
            case 'style': return kindFilter(['style']);
            case 'font': return kindFilter(['font']);
            case 'image': return kindFilter(['image']);
            case 'audio':
            case 'video': return kindFilter(['media']);
            case 'fetch': return kindFilter(['data']);
            default: return null;
        }
    }

    function cssAssetFilter(context) {
        var before = (context.before || '').toLowerCase();
        if (context.kind === 'import' || /@import\s+(?:url\(\s*)?$/.test(before)) { return kindFilter(['style']); }
        if (/@font-face[\s\S]*$/.test(before) || /\bfont\b/.test(before)) { return kindFilter(['font']); }
        if (/\b(?:background|image|mask|cursor|list-style|border|content)\b/.test(before)) {
            return kindFilter(['image', 'media']);
        }
        return null;
    }

    function kindFilter(kinds) {
        return function (asset) {
            return kinds.indexOf(asset.kind) >= 0;
        };
    }

    function shouldIncludeApiForHtml(context) {
        var attr = context.attr;
        var tag = context.tag;
        return attr === 'action' ||
            attr === 'formaction' ||
            ((tag === 'a' || tag === 'area') && attr === 'href');
    }

    function getHtmlAttributeContext(monaco, model, position) {
        var quoted = getQuotedStringInfo(model, position, ['"', "'"]);
        if (quoted) {
            var beforeQuote = quoted.line.slice(0, quoted.quoteIndex);
            var attrMatch = beforeQuote.match(/([:@A-Za-z0-9_-]+)\s*=\s*$/);
            if (!attrMatch) { return null; }
            var tag = findHtmlTag(model, position);
            return {
                prefix: quoted.prefix,
                range: makeRange(monaco, position.lineNumber, quoted.startOffset, quoted.endOffset),
                tag: tag,
                attr: attrMatch[1].toLowerCase(),
                before: beforeQuote
            };
        }

        var line = model.getLineContent(position.lineNumber);
        var offset = position.column - 1;
        var before = line.slice(0, offset);
        var unquoted = before.match(/([:@A-Za-z0-9_-]+)\s*=\s*([^\s"'=<>`]*)$/);
        if (!unquoted) { return null; }
        return {
            prefix: unquoted[2],
            range: makeRange(monaco, position.lineNumber, offset - unquoted[2].length, offset),
            tag: findHtmlTag(model, position),
            attr: unquoted[1].toLowerCase(),
            before: before.slice(0, before.length - unquoted[2].length)
        };
    }

    function adjustSrcsetContext(monaco, context) {
        var prefix = context.prefix || '';
        var startDelta = 0;
        var comma = prefix.lastIndexOf(',');
        if (comma >= 0) { startDelta = comma + 1; }
        while (startDelta < prefix.length && /\s/.test(prefix.charAt(startDelta))) {
            startDelta++;
        }
        if (startDelta === 0) { return context; }

        return {
            prefix: prefix.slice(startDelta),
            range: new monaco.Range(
                context.range.startLineNumber,
                context.range.startColumn + startDelta,
                context.range.endLineNumber,
                context.range.endColumn),
            tag: context.tag,
            attr: context.attr,
            before: context.before
        };
    }

    function getCssUrlContext(monaco, model, position) {
        var line = model.getLineContent(position.lineNumber);
        var offset = position.column - 1;
        var before = line.slice(0, offset);
        var urlMatch = before.match(/url\(\s*(['"]?)([^'")\\]*)$/i);
        if (urlMatch) {
            var prefix = urlMatch[2] || '';
            return {
                kind: 'url',
                prefix: prefix,
                range: makeRange(monaco, position.lineNumber, offset - prefix.length, offset),
                before: before
            };
        }

        var quoted = getQuotedStringInfo(model, position, ['"', "'"]);
        if (!quoted) { return null; }
        var beforeQuote = quoted.line.slice(0, quoted.quoteIndex);
        if (!/@import\s+(?:url\(\s*)?$/i.test(beforeQuote)) { return null; }
        return {
            kind: 'import',
            prefix: quoted.prefix,
            range: makeRange(monaco, position.lineNumber, quoted.startOffset, quoted.endOffset),
            before: beforeQuote
        };
    }

    function getJsStringContext(monaco, model, position) {
        var quoted = getQuotedStringInfo(model, position, ['"', "'", '`']);
        if (!quoted) { return null; }

        var before = quoted.line.slice(0, quoted.quoteIndex);
        var prefix = quoted.prefix || '';
        var intent = jsIntent(before, prefix);
        if (!intent) { return null; }

        return {
            intent: intent,
            prefix: prefix,
            range: makeRange(monaco, position.lineNumber, quoted.startOffset, quoted.endOffset),
            before: before
        };
    }

    function jsIntent(before, prefix) {
        if (/\bimport\s*\(\s*$/.test(before) ||
            /\bfrom\s*$/.test(before) ||
            /^\s*import\s*$/.test(before) ||
            /\b(?:importScripts)\s*\(\s*$/.test(before) ||
            /\b(?:new\s+)?(?:Worker|SharedWorker)\s*\(\s*$/.test(before)) {
            return 'script';
        }

        if (/\bfetch\s*\(\s*$/.test(before) ||
            /\b(?:navigator\.)?sendBeacon\s*\(\s*$/.test(before) ||
            /\b(?:new\s+)?EventSource\s*\(\s*$/.test(before) ||
            /\.open\s*\([^)]*,\s*$/.test(before) ||
            /\bnew\s+URL\s*\(\s*$/.test(before)) {
            return 'request';
        }

        if (/\.(?:src|href|poster)\s*=\s*$/.test(before) ||
            /(?:src|href|poster)\s*:\s*$/.test(before)) {
            return 'asset';
        }

        if (isJsUrlNamedContext(before)) {
            return 'request';
        }

        return null;
    }

    function isJsUrlNamedContext(before) {
        before = String(before || '').toLowerCase();
        return /\b(?:url|uri|endpoint|api|apiurl|apipath|apiendpoint)\s*[:=]\s*$/.test(before) ||
            /\b[A-Za-z_$][\w$]*(?:url|uri|path|endpoint)\s*=\s*$/.test(before);
    }

    function getQuotedStringInfo(model, position, quoteChars) {
        var line = model.getLineContent(position.lineNumber);
        var offset = position.column - 1;
        for (var i = offset - 1; i >= 0; i--) {
            var ch = line.charAt(i);
            if (quoteChars.indexOf(ch) < 0 || isEscaped(line, i)) { continue; }
            return {
                line: line,
                quote: ch,
                quoteIndex: i,
                startOffset: i + 1,
                endOffset: offset,
                prefix: line.slice(i + 1, offset)
            };
        }
        return null;
    }

    function isEscaped(line, index) {
        var slashCount = 0;
        for (var i = index - 1; i >= 0 && line.charAt(i) === '\\'; i--) {
            slashCount++;
        }
        return slashCount % 2 === 1;
    }

    function findHtmlTag(model, position) {
        var lineNumber = position.lineNumber;
        var text = '';
        var firstLine = Math.max(1, lineNumber - 8);
        for (var line = firstLine; line <= lineNumber; line++) {
            var content = model.getLineContent(line);
            if (line === lineNumber) {
                content = content.slice(0, position.column - 1);
            }
            text += content + '\n';
        }

        var lt = text.lastIndexOf('<');
        var gt = text.lastIndexOf('>');
        if (lt < 0 || gt > lt) { return ''; }

        var match = text.slice(lt).match(/^<\s*([A-Za-z][A-Za-z0-9:-]*)/);
        return match ? match[1].toLowerCase() : '';
    }

    function isInsideHtmlElement(model, position, tagName) {
        var text = recentText(model, position, 120).toLowerCase();
        var open = text.lastIndexOf('<' + tagName);
        var close = text.lastIndexOf('</' + tagName);
        return open > close;
    }

    function recentText(model, position, maxLines) {
        var firstLine = Math.max(1, position.lineNumber - maxLines);
        var text = '';
        for (var line = firstLine; line <= position.lineNumber; line++) {
            var content = model.getLineContent(line);
            if (line === position.lineNumber) {
                content = content.slice(0, position.column - 1);
            }
            text += content + '\n';
        }
        return text;
    }

    function makeRange(monaco, lineNumber, startOffset, endOffset) {
        return new monaco.Range(lineNumber, startOffset + 1, lineNumber, endOffset + 1);
    }

    window.setSuggestionCatalog = setSuggestionCatalog;
    window.TryitSuggestions = {
        register: register,
        setCatalog: setSuggestionCatalog
    };
})();
