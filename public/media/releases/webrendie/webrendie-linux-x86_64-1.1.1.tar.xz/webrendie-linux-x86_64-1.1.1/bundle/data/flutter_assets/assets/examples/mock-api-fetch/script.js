// Fetch from the built-in mock API.
// One small client does all the work: fetch the path, always parse the JSON
// (error responses carry a body too), and branch on res.ok. Elapsed time is
// measured around the await so the latency endpoint visibly takes ~800 ms.

const statusLine = document.querySelector('#status');
const output = document.querySelector('#output');
const endpointButtons = document.querySelectorAll('.endpoint');

// The whole demo in one function: request, time, classify, render.
async function run(path) {
  setBusy(true, path);
  setStatus(`${path} - waiting…`, 'busy');

  const started = performance.now();
  try {
    const res = await fetch(path);
    // Every mock route speaks JSON, including errors ({ error, status }).
    const body = await res.json();
    const elapsed = Math.round(performance.now() - started);

    if (!res.ok) {
      setStatus(`${path} → ${res.status} in ${elapsed} ms`, 'error');
      renderBody('error', `${res.status} - the mock router's error body`, body);
      return;
    }

    setStatus(`${path} → ${res.status} OK in ${elapsed} ms`, 'ok');
    const heading = Array.isArray(body)
      ? `${body.length} record${body.length === 1 ? '' : 's'} - a JSON array`
      : 'A single JSON object';
    renderBody('record', heading, body);
  } catch (err) {
    // Only network-level failures reject the promise; the mock never does.
    setStatus(`${path} → request failed`, 'error');
    renderBody('error', 'Request failed', { message: err.message });
  } finally {
    setBusy(false, null);
  }
}

// Pretty-print any body - arrays, objects, error shapes - inside one card.
function renderBody(kind, heading, body) {
  output.replaceChildren();

  const card = document.createElement('article');
  card.className = `card card-${kind}`;

  const title = document.createElement('h2');
  title.textContent = heading;

  const pre = document.createElement('pre');
  pre.textContent = JSON.stringify(body, null, 2);

  card.append(title, pre);
  output.append(card);
}

function setStatus(text, kind) {
  statusLine.textContent = text;
  statusLine.dataset.kind = kind;
}

// Disable every endpoint while one is in flight - the delay demo would
// otherwise invite a click pile-up.
function setBusy(busy, activePath) {
  endpointButtons.forEach((button) => {
    button.disabled = busy;
    button.classList.toggle('is-active', busy && button.dataset.path === activePath);
  });
}

endpointButtons.forEach((button) => {
  button.addEventListener('click', () => run(button.dataset.path));
});

// First paint: prefetch the collection so the panel is never empty.
run('/api/users');
